//
//  TiNetworkManager.h
//  Ti.Network.Manager
//
//  Created by Douglas Alves
//  Copyright (c) 2026 Upflix. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiNetworkManager.
FOUNDATION_EXPORT double TiNetworkManagerVersionNumber;

//! Project version string for TiNetworkManager.
FOUNDATION_EXPORT const unsigned char TiNetworkManagerVersionString[];

#import <TiNetworkManager/TiNetworkManagerModuleAssets.h>
